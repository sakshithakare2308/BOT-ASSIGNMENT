# 🚀 Binance Futures Testnet Trading Bot (Premium Version)

## ✨ Features
- MARKET, LIMIT, STOP orders
- Clean CLI interface
- Input validation
- Structured logging
- Error handling
- Human-readable output

## ⚙️ Setup

1. Install dependencies:
```
pip install -r requirements.txt
```

2. Create `.env` file:
```
API_KEY=your_key
API_SECRET=your_secret
```

## ▶️ Run Examples

### Market
```
python cli.py --symbol BTCUSDT --side BUY --type MARKET --quantity 0.001
```

### Limit
```
python cli.py --symbol BTCUSDT --side SELL --type LIMIT --quantity 0.001 --price 60000
```

### Stop (Bonus)
```
python cli.py --symbol BTCUSDT --side BUY --type STOP --quantity 0.001 --price 55000
```

## 📁 Logs
Check logs/bot.log

## 💡 Notes
- Uses Binance Futures Testnet
- Keep quantity small
- Ensure API keys are valid
