import argparse
from bot.client import BinanceClient
from bot.orders import place_order
from bot.validators import *
from bot.logging_config import setup_logging

def pretty_print(title, data):
    print("\n" + "="*10 + f" {title} " + "="*10)
    for k, v in data.items():
        print(f"{k}: {v}")

def main():
    setup_logging()

    parser = argparse.ArgumentParser(description="Simple Binance Futures Trading Bot")

    parser.add_argument("--symbol", required=True, help="e.g. BTCUSDT")
    parser.add_argument("--side", required=True, help="BUY or SELL")
    parser.add_argument("--type", required=True, help="MARKET / LIMIT / STOP")
    parser.add_argument("--quantity", required=True)
    parser.add_argument("--price", required=False)

    args = parser.parse_args()

    try:
        side = validate_side(args.side)
        order_type = validate_order_type(args.type)
        quantity = validate_quantity(args.quantity)
        price = validate_price(args.price, order_type)

        client = BinanceClient().get_client()

        pretty_print("ORDER INPUT", vars(args))

        order = place_order(
            client,
            args.symbol,
            side,
            order_type,
            quantity,
            price
        )

        response = {
            "orderId": order.get("orderId"),
            "status": order.get("status"),
            "executedQty": order.get("executedQty"),
            "avgPrice": order.get("avgPrice", "N/A")
        }

        pretty_print("ORDER RESPONSE", response)

        print("\n✅ SUCCESS: Order placed!")

    except Exception as e:
        print(f"\n❌ ERROR: {str(e)}")

if __name__ == "__main__":
    main()
